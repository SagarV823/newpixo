package com.pixo.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.pixo.bean.ProfilePicture;
import com.pixo.bean.UploadFile;
import com.pixo.bean.User;
import com.pixo.dao.UserDAO;
import com.pixo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	public UserService userService;
	
	@Autowired
	public UserDAO userDAO;
	
	static Logger logger = Logger.getLogger(UserController.class);
	
	@RequestMapping(value="registerUser",method=RequestMethod.GET)
	public ModelAndView registerUser(@ModelAttribute User user){
		ModelAndView mv=new ModelAndView();
		boolean result=userService.registerUser(user);
		if(result)
			logger.info("Registration successful !");
		else
			logger.warn("Registration failed ! Check EmailId or Password ...");
		mv.addObject("Registerstatus","Successfully registered! Proceed to login Page!");
		mv.setViewName("Login");
		return mv;
	}
	
	@RequestMapping(value="loginUser",method=RequestMethod.POST)
    public ModelAndView UserAuthentication(@RequestParam("EmailId") String emailId,@RequestParam("Password") String password,HttpServletRequest request){	
		
		logger.info("Credential A Authenticating ...");	      	      
	  	ModelAndView mv=new ModelAndView();
    	boolean result=userService.authenticate(emailId, password);
    	HttpSession session=request.getSession();
    	session.setAttribute("EmailId", emailId);
    	
    	if(result){
    		logger.info("Authentication Successful ...");
    		User user=userService.getUser(emailId);
    		String name=user.getName();
    		int id=user.getId();
    		session.setAttribute("UserId", id);
    		mv.addObject("userid",id);
    		mv.setViewName("Welcome");
    		mv.addObject("username",name);
    	}
    	else{	
    		logger.warn("Authentication failed ! Wrong Email or Password ...");	
    		mv.addObject("status","Wrong Email or Password!");
			mv.setViewName("Login");
    	}   	
    	return mv;
    }
	
	 @RequestMapping(value = "uploadPicture", method = RequestMethod.POST)
	    public ModelAndView handleFileUpload(HttpServletRequest request,@RequestParam CommonsMultipartFile[] profilePicture) throws Exception {
	          ModelAndView mv=new ModelAndView();
	        if (profilePicture != null && profilePicture.length > 0) {
	            for (CommonsMultipartFile aFile : profilePicture)
	            {      
	                System.out.println("Saving file: " + aFile.getOriginalFilename());
	                int userId=(int)request.getSession().getAttribute("UserId"); 
	                ProfilePicture pic = new ProfilePicture();
	                pic.setFileName(aFile.getOriginalFilename());
	                pic.setData(aFile.getBytes());
	                pic.setUserId(userId);
	                boolean result=userDAO.uploadProfilePicture(pic);
	                if(result)
	                {
	                	mv.addObject("status","Uploaded succesfully!");
	                	mv.setViewName("Welcome");
	                }
	            }
	        }	  
	        return mv;
	    }
	 @RequestMapping(value = "showImage")
	 public ModelAndView showImage(HttpServletRequest request, HttpServletResponse response){	
			ModelAndView mv=new ModelAndView();	
	    	HttpSession session=request.getSession();
	    	int userId=(int)request.getSession().getAttribute("UserId"); 
	    	ProfilePicture picture=userDAO.showImage(userId);
	    	response.setContentType("image/jpeg, image/jpg, image/png, image/gif");
	        try {
				response.getOutputStream().write(picture.getData());
				response.getOutputStream().close();
			} catch (IOException e) {			
				e.printStackTrace();
			}	        
	    	mv.addObject("image",picture);
	    	mv.setViewName("Welcome");
	    	return mv;
	    }
}
