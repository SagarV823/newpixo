package com.pixo.dao;

import com.pixo.bean.ProfilePicture;
import com.pixo.bean.User;

public interface UserDAO {

	public boolean registerUser(User user);
	public boolean authenticate(String email,String password);
	public User getUser(String email);
	public boolean uploadProfilePicture(ProfilePicture pic);
	public ProfilePicture showImage(int id);
}
