package com.pixo.dao;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.pixo.bean.UploadFile;
import com.pixo.bean.User;

@Repository
public class FileUploadDAOImpl implements FileUploadDAO {

	
	@Autowired
    private SessionFactory sessionFactory;
     
    public FileUploadDAOImpl() {
    }
 
    public FileUploadDAOImpl(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
 
    @Override
    @Transactional
    public void save(UploadFile uploadFile) {
        sessionFactory.getCurrentSession().save(uploadFile);
    }

	@Override
    @Transactional
	public UploadFile ShowImage(int id) {
		Session session=null;
		session=sessionFactory.getCurrentSession();
		Query query=session.createQuery("from UploadFile where FILE_ID=?");
		query.setParameter(0,id);
		UploadFile file=(UploadFile)query.getSingleResult();
		return file;	
	}

}
