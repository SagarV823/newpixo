package com.pixo.dao;

import com.pixo.bean.UploadFile;

public interface FileUploadDAO {

	void save(UploadFile uploadFile);
	public UploadFile ShowImage(int id);
}
